#!/bin/bash

################################################################################
# System Information Script
# Purpose: Display comprehensive system information
# Author: Learning Exercise
# Date: $(date +%Y-%m-%d)
################################################################################

# Colors for better output (optional - makes it look nice!)
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print section headers
print_header() {
    echo -e "\n${BLUE}========================================${NC}"
    echo -e "${YELLOW}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

# Function to print info lines
print_info() {
    echo -e "${GREEN}$1:${NC} $2"
}

# Start of script
clear
echo -e "${YELLOW}╔════════════════════════════════════════╗${NC}"
echo -e "${YELLOW}║   SYSTEM INFORMATION DASHBOARD        ║${NC}"
echo -e "${YELLOW}╔════════════════════════════════════════╗${NC}"

# 1. USER INFORMATION
print_header "User Information"
print_info "Current User" "$(whoami)"
print_info "User ID" "$(id -u)"
print_info "Group ID" "$(id -g)"
print_info "Home Directory" "$HOME"
print_info "Current Shell" "$SHELL"

# 2. SYSTEM INFORMATION
print_header "System Information"
print_info "Hostname" "$(hostname)"
print_info "Operating System" "$(uname -s)"
print_info "Kernel Version" "$(uname -r)"
print_info "Architecture" "$(uname -m)"
print_info "Uptime" "$(uptime -p 2>/dev/null || uptime)"

# 3. DATE & TIME
print_header "Date & Time"
print_info "Current Date" "$(date '+%A, %B %d, %Y')"
print_info "Current Time" "$(date '+%I:%M:%S %p %Z')"
print_info "Timezone" "$(date '+%Z (UTC%z)')"

# 4. LOGGED IN USERS
print_header "Logged In Users"
LOGGED_USERS=$(who | wc -l)
print_info "Number of Users" "$LOGGED_USERS"
if [ $LOGGED_USERS -gt 0 ]; then
    echo -e "\n${GREEN}Active Sessions:${NC}"
    who | awk '{printf "  • %-10s on %-10s at %s %s\n", $1, $2, $3, $4}'
fi

# 5. MEMORY INFORMATION
print_header "Memory Usage"
if command -v free &> /dev/null; then
    TOTAL_MEM=$(free -h | awk '/^Mem:/ {print $2}')
    USED_MEM=$(free -h | awk '/^Mem:/ {print $3}')
    FREE_MEM=$(free -h | awk '/^Mem:/ {print $4}')
    print_info "Total Memory" "$TOTAL_MEM"
    print_info "Used Memory" "$USED_MEM"
    print_info "Free Memory" "$FREE_MEM"
else
    echo "  Memory information not available"
fi

# 6. DISK USAGE
print_header "Disk Usage"
print_info "Current Directory" "$(pwd)"
print_info "Disk Space (Current)" "$(du -sh . 2>/dev/null || echo 'N/A')"
echo -e "\n${GREEN}Filesystem Usage:${NC}"
df -h | awk 'NR==1 {printf "  %-20s %8s %8s %8s %5s %s\n", $1, $2, $3, $4, $5, $6} 
             NR>1  {printf "  %-20s %8s %8s %8s %5s %s\n", $1, $2, $3, $4, $5, $6}' | head -6

# 7. CPU INFORMATION
print_header "CPU Information"
if [ -f /proc/cpuinfo ]; then
    CPU_MODEL=$(grep "model name" /proc/cpuinfo | head -1 | cut -d: -f2 | xargs)
    CPU_CORES=$(grep -c "processor" /proc/cpuinfo)
    print_info "CPU Model" "$CPU_MODEL"
    print_info "CPU Cores" "$CPU_CORES"
else
    echo "  CPU information not available"
fi

# 8. NETWORK INFORMATION
print_header "Network Information"
if command -v hostname &> /dev/null; then
    print_info "Hostname" "$(hostname -f 2>/dev/null || hostname)"
fi
if command -v ip &> /dev/null; then
    IP_ADDR=$(ip addr show | grep "inet " | grep -v "127.0.0.1" | awk '{print $2}' | cut -d/ -f1 | head -1)
    print_info "IP Address" "${IP_ADDR:-N/A}"
fi

# 9. RUNNING PROCESSES
print_header "Process Information"
PROCESS_COUNT=$(ps aux | wc -l)
print_info "Total Processes" "$((PROCESS_COUNT - 1))"
print_info "Current PID" "$$"

# 10. CURRENT DIRECTORY CONTENTS
print_header "Current Directory"
print_info "Location" "$(pwd)"
FILE_COUNT=$(ls -1 | wc -l)
DIR_COUNT=$(ls -ld */ 2>/dev/null | wc -l)
print_info "Files" "$FILE_COUNT"
print_info "Directories" "$DIR_COUNT"

# 11. SYSTEM LOAD (if available)
print_header "System Load"
if [ -f /proc/loadavg ]; then
    LOAD_AVG=$(cat /proc/loadavg | awk '{print $1, $2, $3}')
    print_info "Load Average (1,5,15 min)" "$LOAD_AVG"
else
    echo "  Load average not available"
fi

# Footer
echo -e "\n${BLUE}========================================${NC}"
echo -e "${YELLOW}Report generated at: $(date)${NC}"
echo -e "${BLUE}========================================${NC}\n"

# Optional: Save to file
if [ "$1" == "--save" ]; then
    OUTPUT_FILE="system_info_$(date +%Y%m%d_%H%M%S).txt"
    # Re-run without colors and save
    TERM=dumb $0 > "$OUTPUT_FILE"
    echo -e "${GREEN}Report saved to: $OUTPUT_FILE${NC}"
fi

exit 0
